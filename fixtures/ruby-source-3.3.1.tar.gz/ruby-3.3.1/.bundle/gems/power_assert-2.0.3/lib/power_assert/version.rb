module PowerAssert
  VERSION = "2.0.3"
end
